import config
import os
import uuid
import sys
from azure.storage.blob import BlockBlobService, PublicAccess
from azure.storage.blob.models import ContentSettings
from azure.common.client_factory import get_client_from_cli_profile

def publish_file_system(data):

    config.logging.debug('################### Begin publishing the report ###################')

    if config.publish_path != "":
        save_path = config.publish_path
    else:
        save_path = os.getcwd()

    name_of_file = 'report'

    file_name = name_of_file
    full_file_path = os.path.join(save_path, file_name + '.html')         

    file1 = open(full_file_path, 'w')

    toFile = data

    file1.write(toFile)

    file1.close()   
    config.logging.debug('#################### End publishing the report ####################')

def publish_blob(subscription_id, data):

    config.logging.debug('#################### Begin publishing the report ####################')

    try:

        storage_account_name = 'bedrockasbuilt'

        # Create the BlockBlobService that is used to call the Blob service for the storage account
        blob_service_client = BlockBlobService(
            # TODO: remove key later
            account_name=storage_account_name, account_key='RYrM+FqlKF88TL1+YyJQoDwLlMEPEQp7F4aTsBUfZVh3nJlDubsgwW9dTjN/uI1Wxgq/b2vWnCuPncaa0525cw==') 

        # Create a container with the name of the subscription_id
        container_name = subscription_id
        blob_service_client.create_container(container_name)

        # Set the permission so the blobs are public.
        blob_service_client.set_container_acl(
            container_name, public_access=PublicAccess.Container) # TODO: change this to be least priv. later

        save_path = os.getcwd()

        # REPORT
        report_file_name = config.report_file_name
        full_file_path = os.path.join(save_path, report_file_name + '.html')         

        file1 = open(full_file_path, 'w')
        file1.write(data)
        file1.close()   
    
        # Upload the created file, use local_file_name for the blob name
        blob_service_client.create_blob_from_path(
            container_name, report_file_name + '.html', full_file_path, ContentSettings(content_type = 'text/html')) # set content-type to allow in browser and not download

        # LOGO
        logo_file_name = config.logo_file_name
        logo_full_file_path = os.path.join(save_path, logo_file_name)         

        blob_service_client.create_blob_from_path(
            container_name, logo_file_name, logo_full_file_path, ContentSettings(content_type = 'image/svg+xml')) 


        config.logging.info('🔥🔥🔥🔥🔥🔥 The URL for the report is: https://{}.blob.core.windows.net/{}/Report.html 🔥🔥🔥🔥🔥🔥'.format(storage_account_name, subscription_id))
        config.logging.debug('#################### End publishing the report ####################')

    except Exception as e:
        config.logging.error(e)


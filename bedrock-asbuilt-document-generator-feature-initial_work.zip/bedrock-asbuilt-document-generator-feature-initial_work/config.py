import json
import logging
import argparse

# Setup defaults from config file
config = json.load(open('config.json'))

# Setup defaults from config
loggingFormat = config['logging_format']
publish_path = config['publish_path']
none_character = config['none_character']
report_style = config['report_style']
report_title = config['report_title']
report_file_name = config['report_file_name']
logo_file_name = config['logo_file_name']

parser = argparse.ArgumentParser(description='A script to generate an as-built documentation of ms-azure resources')

# application config
parser.add_argument('-d','--debug', help='Run the app in debug mode for extra logging',metavar='', default='false')
parser.add_argument('-c','--config', help='The documentation config location component',metavar='', default='config.json')

parser.add_argument('-s','--subscriptionid', help='Azure Subscription ID',metavar='')  
parser.add_argument('-x','--context', help='the context to run in: client or app',metavar='', default='client')  
parser.add_argument('-o','--output', help='Output Format', choices=['html', 'txt'], metavar='')
args = parser.parse_args()

output = args.output

if args.debug == 'true':
    logging.basicConfig(format=loggingFormat, level=logging.DEBUG)
else:
    logging.basicConfig(format=loggingFormat, level=logging.DEBUG)
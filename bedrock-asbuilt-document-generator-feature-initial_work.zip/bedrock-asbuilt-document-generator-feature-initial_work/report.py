import config
from prettytable import PrettyTable

# ---------------------------------------------------------------------------------------------------------------------
# Get Output Object
# ---------------------------------------------------------------------------------------------------------------------
def output_to_string(title, columns, data):
    """
    This function outputs to string or html
    :param title:  The title
    :param columns:  The columns in the output
    :param data:  The data used in the output
    :return: The formatted output
    """
    
    output = config.args.output

    t = PrettyTable(columns)
    t.title = title
    
    for row in data:
        t.add_row(row)
    if len(t._rows) >0 :
        if output == 'html':
            formattedHtml = t.get_html_string()
            return(config.report_style + '<h2>' + title + '</h2>' + formattedHtml)
        else:
            return(t.get_string())
    else:
        return('<h2>' + title + '</h2><p>NO DATA AVAILABLE</p>')


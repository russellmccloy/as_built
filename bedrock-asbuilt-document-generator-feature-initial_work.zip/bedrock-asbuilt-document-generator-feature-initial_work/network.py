import report
import config
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.network import NetworkManagementClient
from azure.common.client_factory import get_client_from_cli_profile

def get_vnets():
    """
    This function returns vnets and their properties
    :return: Vnets and their properties
    """
    
    virtual_networks = []   
 
    resource_client =  get_client_from_cli_profile(ResourceManagementClient)
    network_client =  get_client_from_cli_profile(NetworkManagementClient)

    for vnet in resource_client.resources.list(filter=f"resourceType eq 'Microsoft.Network/virtualNetworks'"):   

        rg = vnet.id.split('/')[4]

        subnets = []

        subbys = ''
        for subnet in network_client.subnets.list(rg, vnet.name):

            subnets.append([subnet.name])

            subbys += subnet.name + '\n'

        nsgs = []

        nsgiies = ''
        for nsg in network_client.network_security_groups.list(rg):
            config.logging.debug(nsg.name)
        
            nsgs.append([nsg.name])
            nsgiies += nsg.name + '\n'

        virtual_networks.append([vnet.name, vnet.location, rg, subbys, nsgiies])

    data = report.output_to_string('Vnets',['Name','Location','Resource Groups', 'Subnets', 'NSGs'], virtual_networks)

    if data is None: 
        return ''
    else:
        return data
import report
import config
from azure.mgmt.recoveryservices import RecoveryServicesClient
from azure.mgmt.recoveryservicesbackup import RecoveryServicesBackupClient
from azure.common.client_factory import get_client_from_cli_profile

def get_recovery_services_vaults():
    """
    This function returns recovery services vaults and their properties
    :return: Recovery services vaults and their properties
    """ 

    vaults = []

    rsv_client = get_client_from_cli_profile(RecoveryServicesClient)
    rsv_backup_client = get_client_from_cli_profile(RecoveryServicesBackupClient)

     # RECOVERY SERVICES
    for rsv in rsv_client.vaults.list_by_subscription_id():

        backup_policies = []

        rg = rsv.id.split('/')[4]
        backups = ''

        for rs_backup_policy in rsv_backup_client.backup_policies.list(rsv.name, rg):
            backup_policies.append([rs_backup_policy.name])

            backups += rs_backup_policy.name+ '\n'

        vaults.append([rsv.name, rsv.location, backups])

    data = report.output_to_string('Recovery Service Vaults',['Name','Location', 'Backup Policies'], vaults)

    if data is None: 
        return ''
    else:
        return data

import config
import logging
import subscription
import resource_groups
import key_vaults
import storage
import network
import recoveryservices
import private_dns_zones
import security
import publish

def main():
     
    # Set the title for the report
    subscription_name = config.report_title.format(subscription = subscription.get_subscription_name(config.args.subscriptionid), subscription_id = config.args.subscriptionid)

    # Build up the report
    data = subscription_name
    data += subscription.get_subscription(config.args.subscriptionid)

    if(config.args.context == 'app'):    

        data += resource_groups.get_resource_groups()

    elif(config.args.context == 'client'):
            
        data += security.get_pricing_list()
        data += resource_groups.get_resource_groups()
        data += key_vaults.get_key_vaults()
        data += storage.get_storage_accounts()
        data += network.get_vnets()
        data += recoveryservices.get_recovery_services_vaults()
        data += private_dns_zones.get_private_dns_zones()
    
    # Publish the report to blob storage
    publish.publish_blob(config.args.subscriptionid, data)
    # publish.publish_file_system(data)

if __name__ == '__main__':
    main()




import report
import config
from azure.mgmt.storage import StorageManagementClient
from azure.common.client_factory import get_client_from_cli_profile

def get_storage_accounts():
    """
    This function returns storage accounts and their properties
    :return: Storage accounts and their properties
    """

    storage_accounts = []

    client = get_client_from_cli_profile(StorageManagementClient)

    accounts = client.storage_accounts.list()

    for sa in accounts:

        rg = sa.id.split('/')[4]
        
        storage_accounts.append([sa.name, sa.location, rg])

    data = report.output_to_string('Storage Accounts',['Name','Location','Resource Groups'], storage_accounts)

    if data is None: 
        return ''
    else:
        return data




# SUMMARY

This document outlines how a developer can integrate this pipeline template into their pipeline to generate an **As Built Report**.

## HOW TO USE

- As you can see from the following code there is not much to do.

```yaml
name: AsBuilt Report ($(BuildDefinitionName).$(Date:yyyyMMdd)_$(Rev:.r))

resources:
  repositories:
  - repository: as_built_template
    type: github
    name: lab3au/bedrock-asbuilt-document-generator
    ref: 'refs/heads/feature/initial_work' # should be master
    endpoint: 'Landing Zone Generator'

trigger:
  branches:
    include:
    - master
    - feature/*

pr:
  branches:
    include:
    - feature/*
    
stages:

- stage: AsBuilt

  displayName: 'Run AsBuilt Report'

  jobs:

  - template: pipeline.yaml@as_built_template 
    parameters:
      pool:
        vmImage: 'ubuntu-latest'
      report_param_debug: '<true or false>'                   # Run in debug mode or not
      report_param_config: '<config.json>'                    # The config file to use
      report_param_subscriptionid: '<YOUR SUBSCRIPTION ID>'   # The subscription id where your resources are deployed
      report_param_context: '<YOUR CONTEXT>'                  # The context to run the report in
      report_param_output: '<html or txt>'                    # The output format of the report
```

1. Add the above **STAGE** block to your pipeline
2. Update the following:
   - dependsOn
   - report_param_debug
   - report_param_config
   - report_param_subscriptionid
   - report_param_context
   - report_param_output

That's all there is to it.

## AZURE DEVOPS SERVICE CONNECTION

- You will need an Azure DevOps service connection which is linked to an Azure AAD app registration
- The app registration will needthe following API permission:

```bash
Azure Active Directory Graph (1) ==> Directory.Read.All
```

## HOW TO RUN FROM COMMAND LINE

Here are some samples of how to run from your command line.

> Note: you will need to ensure your machine has the correct setup for Python etc but that is outside the scope of this README

- get the As Built report for a subscription (client context level)

```bash
python3 app.py -s 551eff55-7871-4673-9b0f-d4946f7570c5 -x 'client' --output html
```

- Get the As Built report for an app (app context level)
  
```bash
python3 app.py -s 551eff55-7871-4673-9b0f-d4946f7570c5 -x 'app' --output html
```

## PARAMETERS EXPLAINED

There are a few more parameters that can be passed to this pipeline template and these are explained below.

> *Please note that you should not need to care about most of these parameters*

|        Parameter Name        | Parameter switches short/long |         Pipeline Parameter                |                                               Description                                                         |
|------------------------------|-------------------------------|-------------------------------------------|-------------------------------------------------------------------------------------------------------------------|
|        debug                 |   -d      --debug             |	report_param_debug                       |    Run in debug mode, it is very verbose Good for troubleshooting.                                                |
|        config                |   -c      --config            |	report_param_config                      |    You can override the default configuration for the app *(config.json)*                                         |
|        subscription-id       |   -s      --subscription-id   |	report_param_subscriptionid              |    You must specify this                                                                                          |
|        context               |   -x      --context           |	report_param_context                     |    Run for **client context** or **app context**                                                                  |
|        storage account       |   -a      --stor              |	report_param_storage_account_for_report  |    The storage account to stor the rport in                                                                       |
|        output                |           --output            |	report_param_output                      |    The out put type. Text or HTML. For SharePoint use HTML only. The default is HTML                              |

## HOW IT WORKS

The application is written in Python. It uses the Python SDK for Azure to interrogate Azure resources. It builds up a simple HTML report containing all the resources that are returned.

## THE REPORT

The report will be be published to a storage account inside a container pertaining to the subscription id
## THE FUTURE

In my opinion, we should be doing this differently.

We should:

- run the report and push the raw data to a storage account or database
- we should use PowerBI and maybe Azure Data Factory to transform the data and make a user friendly sortable / filterable report
- push this report to SharePoint or some other medium
import report
import config
from azure.mgmt.privatedns import PrivateDnsManagementClient
from azure.common.client_factory import get_client_from_cli_profile

# none in this subscription use: ee83cffe-9692-4975-b8a5-b4b9fe2c1d33
def get_private_dns_zones():
    """
    This function returns private dns zones and their properties
    :return: Private dns zones and their properties
    """    
    
    private_dns_zones = []

    client = get_client_from_cli_profile(PrivateDnsManagementClient)

    dns_zones = client.private_zones.list()

    for zone in dns_zones:

        rg = zone.id.split('/')[4]

        virtual_network_links = client.virtual_network_links.list(rg, zone.name)

        vnet_links = []

        vnet_links_string = ''

        for virtual_link in virtual_network_links:

            vnet_links.append([virtual_link.name, rg, virtual_link.virtual_network])

            vnet_links_string += virtual_link.name + ' ===> ' + virtual_link.virtual_network.id + '\n'

        private_dns_zones.append(
            [zone.name, zone.location, rg, vnet_links_string])

    data = report.output_to_string(
        'Private DNS Zones',['Name', 'Location', 'Resource Group', 'Virtual Network Links'], 
        private_dns_zones)

    if data is None: 
        return ''
    else:
        return data


#  'max_number_of_record_sets', 'max_number_of_virtual_network_links','number_of_virtual_network_links','max_number_of_virtual_network_links_with_registration','number_of_virtual_network_links_with_registration'
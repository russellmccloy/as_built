import config

def replace_none_with_character(s):
    return config.none_character if s is None else str(s)
import report
import config
import common
import security
from azure.mgmt.resource import SubscriptionClient
from azure.mgmt.monitor import MonitorClient
from azure.common.client_factory import get_client_from_cli_profile

def get_subscription_name(subscriptionId):
    """
    This function returns the subscription name
    :param subscriptionId:  The id of the subscription 
    :return: The subscription name
    """

    subscription_client = get_client_from_cli_profile(SubscriptionClient)
    subscription = subscription_client.subscriptions.get(subscriptionId)

    return subscription.display_name
    
def get_subscription(subscriptionId):
    """
    This function returns the subscription and related properties
    :param subscriptionId:  The id of the subscription 
    :return: The subscription and related properties
    """    

    subscriptions = []

    subscription_client = get_client_from_cli_profile(SubscriptionClient)
    monitor_client = get_client_from_cli_profile(MonitorClient)

    subscription = subscription_client.subscriptions.get(subscriptionId)
    
    diags = ''

    diagnostic_settings = monitor_client.diagnostic_settings.list('/subscriptions/' + subscriptionId).value

    if not diagnostic_settings:

        diags += 'There are no diagnostic settings turned on for this subscription'
    else:
        for diag_setting in diagnostic_settings:

            diags += (
                'Storage Account:' + common.replace_none_with_character(diag_setting.storage_account_id) + '\n'
                'Log Analytics:' + common.replace_none_with_character(diag_setting.workspace_id) + '\n'
                'Service Bus: ' + common.replace_none_with_character(diag_setting.service_bus_rule_id) +  '\n'
                'Event Hub: ' + common.replace_none_with_character(diag_setting.event_hub_authorization_rule_id) + '\n')


    subscriptions.append([subscription.id, 
        subscription.display_name, 
        subscription.tenant_id, 
        subscription.state, 
        subscription.authorization_source, 
        subscription.tags, 
        subscription.subscription_policies.location_placement_id, 
        subscription.subscription_policies.quota_id, 
        subscription.subscription_policies.spending_limit, diags])

    data = report.output_to_string('Subscription',['Id','Display Name','Tenant Id','state','Authorization Source','tags','Location Placement Id', 'Quota Id', 'Spending Limit', 'Diagnostic Settings'], subscriptions)

    if data is None: 
        return ''
    else:
        return data

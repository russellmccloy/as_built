import report
import config
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.keyvault import KeyVaultManagementClient
from azure.common.client_factory import get_client_from_cli_profile

def get_key_vaults():
    """
    This function returns keyvaults and their properties
    :return: Keyvaults and their properties
    """

    vaults = []

    client = get_client_from_cli_profile(KeyVaultManagementClient)

    keyvaults = client.vaults.list()

    for kv in keyvaults:

        rg = kv.id.split('/')[4]

        vaults.append([kv.name, kv.location, rg])

    data = report.output_to_string('Key Vaults',['Name','Location','Resource Groups'], vaults)

    if data is None: 
        return ''
    else:
        return data


import report
import config
from azure.mgmt.security import SecurityCenter
from azure.common.client_factory import get_client_from_cli_profile

def get_pricing_list():
    """
    This function returns a list of pricings and their properties
    :return: List of pricings and their properties
    """

    pricing_list = []

    client = get_client_from_cli_profile(SecurityCenter, asc_location="australiasoutheast")

    pricings = client.pricings.list()

    for pricing in pricings.value:

        pricing_list.append([pricing.name, pricing.type, pricing.pricing_tier])

    data = report.output_to_string('Subscription Security Center Pricing',['Name','Type','Tier'], pricing_list)

    if data is None: 
        return ''
    else:
        return data
# client = SecurityCenter(credentials, subscription_id, asc_location="centralus")
# client.alerts.list() # Returns an iterable object, use a list() if you want it as a list
import report
import config
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.authorization import AuthorizationManagementClient
from azure.graphrbac import GraphRbacManagementClient
from azure.common.client_factory import get_client_from_cli_profile

def get_resource_groups():
    """
    This function returns resource groups and their properties
    :return: Resource groups and their properties
    """

    resource_groups = []

    client = get_client_from_cli_profile(ResourceManagementClient)
    amcclient = get_client_from_cli_profile(AuthorizationManagementClient)
    adclient = get_client_from_cli_profile(GraphRbacManagementClient) 

    rgs = client.resource_groups.list()

    for rg in rgs:

        scope = rg.id

        permissions = ""

        for permitem in amcclient.role_assignments.list_for_scope(scope):

            if permitem.principal_type == 'Group' and permitem.scope == scope:
                try:
                    group = adclient.groups.get(permitem.principal_id)
                    role_definition = amcclient.role_definitions.get_by_id(permitem.role_definition_id)
                    permissions = permissions + group.display_name + " ("+role_definition.role_name +")\n"     
                except:
                    config.logging.debug("An exception occurred: could not get AAD group information")
                    raise

        resource_groups.append([rg.name, rg.location, permissions])
            
    data = report.output_to_string('Resource Groups',['Name','Location','Permissions'], resource_groups)

    if data is None: 
        return ''
    else:
        return data

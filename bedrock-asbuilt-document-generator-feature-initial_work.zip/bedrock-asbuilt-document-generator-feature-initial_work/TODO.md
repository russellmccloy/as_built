# My Todo List

## workflow

- submit requst = 2* sub Ids - NON-PROD / PROD
- prepare sub - activity log enablement / onboard sub to Azure Defender / rename the sub / partners (subs are in a holding area . 200 for example.. name like NO_NOT_USE1 => 200)
- create resources - networks, SA, KV, RSV overall these are platform resources
- then my report gets run on the sub and the platform resources (some props are not on the sub. is it on boarded to Defender for example)

## List of Resources

- Subscription Details (Name, activity Logging status, Security Centre (Azure Defender) Protection status etc)
- RGs - ✔
- KVs - ✔
- Storage accounts - ✔
- VNETs - ✔
- Subnets - ✔
- NSGs - ✔
- RSVs + Backup Policies - ? - havent done Backup policies yet - ✔
- Private DNS zones and their Linkages to VNETs - MAKE SURE YOU SWITCH TO SUB: ee83cffe-9692-4975-b8a5-b4b9fe2c1d33 - ✔
- List the AD groups for RGS - Look at AusSuper code
- For KVs ad Access poicies - Look at AusSuper code

Considering this is an artefact that we’d look to handover to Application Teams as their “Landing Zone” is built we’d probably need to understand is Where is this run from? How often?

## Subscription

- name

### Is Activity Log Enabled

- is activity log enabled - where is the data sent? Name of LAW. could be SA could be EH - ✔

### Is onboarded to security center / defender??

```bash
Set-AzContext -Subscription "d07c0080-170c-4c24-861d-9c817742786c"
Set-AzSecurityPricing -Name "default" -PricingTier "Standard"
```

### Important points

- really underatand the minimum permissions required to get each piece of info - an SPN iis created with READ ONLY access to subscription - ✔
- what permissions does the SPN need... least priveledge - READ ONLY?

## OTHER STUFF

<https://docs.microsoft.com/en-us/powershell/module/az.security/get-azsecuritypricing?view=azps-5.2.0>
Chat with Dario: 09/12/2020 @ 14:22 for 10 minutes
<https://docs.microsoft.com/en-us/cli/azure/security/pricing?view=azure-cli-latest>

import requests
import json
import globals


def _url(path):
    """
    Builds up the URL path based on the passed in variables
    :param path:  The specific path segment for the REST call
    :return: the full url including the passed in path
    """
    url = (
        "https://dev.azure.com/"
        + globals.Shared.ORG
        + "/"
        + globals.Shared.PROJECT
        + "/_apis/git"
        + path
        + "?api-version="
        + globals.Shared.VERSION
    )
    return url


def create(name):
    """
    This function responds to a POST request to /repositories that creates a repository
    if it doesn't already exist.
    :param name:  The name of the repository that will be created
    :return: the result of the request
    """
    return requests.post(
        _url("/repositories"),
        json={"name": name, "project": {"id": globals.Shared.PROJECT_ID}},
        headers={"Authorization": "Basic " + globals.Shared.AUTH_TOKEN_ENCODED},
    )


# Create Repository Files
def create_files(repository_id, repository_type, repository_item):
    """
    This function responds to a POST request to /repositories/<repository_id>/pushes that
    creates files in the repository.
    :param repository_id:  The id of the repository that will hold the files
    :param repository_type:  The type of the repository
    :param repository_item:  The whole item from the list_of_repositories.json file
    :return: the result of the request
    """

    with open(
        "json_files/" + repository_type.name.lower() + "_repository_files.json"
    ) as repository_files:
        repository_files_data = json.load(repository_files)

    # foreach changes - change some placeholders in the file
    changes = repository_files_data["commits"][0]["changes"]

    for change in changes:
        if change["item"]["path"].lower() == "pipeline.yaml".lower():

            # open pipeline template for this repository type and store it in json object
            with open(
                "pipeline_templates/" + repository_type.name.lower() + "_pipeline.yaml"
            ) as pipeline_file:
                change["newContent"]["content"] = pipeline_file.read()

            # changes things if we can find them but if not, doesn't matter.
            # ie.. only TF has __state_container_name__ and __state_file_name__
            change["newContent"]["content"] = change["newContent"]["content"].replace(
                "__build_def_prefix__", repository_item["name"]
            )

            change["newContent"]["content"] = change["newContent"]["content"].replace(
                "__state_file_name__", repository_item["name"]
            )

            if "solution" in repository_item:
                change["newContent"]["content"] = change["newContent"][
                    "content"
                ].replace("__solution__", repository_item["solution"])

            if "env" in repository_item:
                change["newContent"]["content"] = change["newContent"][
                    "content"
                ].replace("__env__", repository_item["env"])

        if change["item"]["path"].lower() == "TF/backend.tf".lower():
            change["newContent"]["content"] = change["newContent"]["content"].replace(
                "__state_file_name__", repository_item["name"]
            )

    return requests.post(
        _url("/repositories/" + repository_id + "/pushes"),
        json=repository_files_data,
        headers={"Authorization": "Basic " + globals.Shared.AUTH_TOKEN_ENCODED},
    )

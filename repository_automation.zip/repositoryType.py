import enum


class RepositoryType(enum.Enum):
    """
    An enum to support repository types
    """

    STANDARD = (
        1  # Nearly an empty repository if it the following types don't suit your needs
    )
    TERRAFORM_AZURERM = 2
    # Use for an azurerm project that consumes Terraform module but is not a
    # module itself. The pipeline, if added, will be a standard pipeline without a TFVARS File.
    TERRAFORM_AZURERM_TFVARS = 3
    # Use for an azurerm project that consumes Terraform module but is
    # not a module itself. The pipeline, if added,  can work with a TFVARS file
    TERRAFORM_GCP = 4
    # Use for an GCP project that consumes Terraform module
    PY = 5
    # Use for a Python project
    ANSIBLE = 6
    # Use for an Ansible project
    TERRAFORM_AZURERM_MODULE = 7
    # Use when you are creating a new azurerm Terraform module - name should start with
    # 'terraform -azurerm-'
    TERRAFORM_GCP_MODULE = 8
    # Use when you are creating a new GCP Terraform module - name should start with
    # 'terraform -azurerm-'

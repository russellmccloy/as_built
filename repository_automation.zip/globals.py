import sys
import base64

"""
Variables passed into the script from Azure DevOps or command line.
Sample command line:

python main.py
    <DevOps PAT> <DevOps Project id> <DevOps Org> <DevOps Project name> <DevOps REST API version>

 python main.py
    <SECRET> 553e696e-c449-46e4-a760-95b0eb618ed6 australiansuper Cloud%20Capability 5.1
"""


class Shared:

    AUTH_TOKEN = sys.argv[1]
    AUTH_TOKEN_ENCODED = base64.b64encode(AUTH_TOKEN.encode()).decode()
    PROJECT_ID = sys.argv[2]
    ORG = sys.argv[3]
    PROJECT = sys.argv[4]
    VERSION = sys.argv[5]

    # Variables that can be passed in at a future date for other teams and other DevOps projects
    # - ie.. we use the 'Cloud Capability' DevOps project but other teams don't
    QUEUE_ID = 7
    QUEUE_NAME = "Hosted Ubuntu 1604"
    QUEUE_URL = "https://dev.azure.com/australiansuper/_apis/build/Queues/7"

    QUEUE_POOL_ID = 7
    QUEUE_POOL_NAME = "Hosted Ubuntu 1604"
    QUEUE_POOL_IS_HOSTED = True

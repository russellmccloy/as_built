import repository
import pipeline
import validator
import json
import requests
import repositoryType

LOG_LINE = "######################################################################################"


def process_file():
    # Read the list of current repositories and their types

    with open("json_files/list_of_repositories.json") as list_of_repositories:
        list_of_repositories_data = json.load(list_of_repositories)
        """
        Loop through repositories and create if they don't exist
        (HTTP error of 409 indicates there is a conflict
        and hence the repository already exists)
        """

        for repository_item in list_of_repositories_data:

            repository_type = determine_repository_type(repository_item)

            # Actual call to create repository
            print(LOG_LINE)

            if validator.validate(repository_item):

                repository_response = create_repository(repository_item["name"])

                # if the repository was created we can create the files
                if repository_response.status_code == 201:

                    repository_files_response = create_files(
                        repository_response.json()["id"],
                        repository_type,
                        repository_item,
                    )

                    if repository_files_response.status_code == 201:

                        if "create_pipeline" in repository_item:
                            if repository_item["create_pipeline"] is True:
                                create_pipeline(
                                    repository_item["name"],
                                    repository_item["type"],
                                    repository_item["pipeline_folder_name"],
                                )
                        else:
                            print(
                                "Not Creating a pipeline for {} "
                                "as one was not requested".format(
                                    repository_item["name"]
                                )
                            )

                if repository_response.status_code == 409:
                    print("Repository already exists")
                    print(LOG_LINE)
                    continue

                print(LOG_LINE)

            else:
                print(
                    "The repository name " + repository_item["name"] + " is not valid"
                )
                print(LOG_LINE)


def determine_repository_type(repository_item):
    """
    Determines the repository type.
    :param repository_item: The type of the repository
    :return: the repository type
    """
    if not repository_item["type"]:
        repository_type = repositoryType.RepositoryType.STANDARD
    else:
        repository_type = repositoryType.RepositoryType[repository_item["type"]]
    return repository_type


def create_repository(repository_name):
    """
    Creates a repository if it doesn't already exist.
    :param repository_name: The name of the repository that will be created
    :return: the json response
    """
    print("Creating repository with name: {}".format(repository_name))

    resp = ""

    try:
        resp = repository.create(repository_name)
        resp.raise_for_status()
        print(
            "{}: Successfully created repository "
            "with Id: {}".format(resp.status_code, resp.json()["id"])
        )

    except requests.exceptions.HTTPError as err:
        print("Could not create the repository: {}".format(err))

    return resp


def create_files(repository_id, repository_type, repository_item):
    """
    Creates files inside a repository.
    It creates either files that suit Terraform or Standard.
    :param repository_id:  The id of the repository that will be created
    :param repository_type: The type of the repository that will be created
    :param repository_item:  The whole item from the list_of_repositories.json file
    :return: the json response
    """
    print(
        "Now we will create the initial files for the repository based on the type of repository "
        "requested in the list_of_repositories.json file"
    )

    resp = ""

    try:
        # Create repository files depending on repository type (TF OR STANDARD TYPE)
        resp = repository.create_files(repository_id, repository_type, repository_item)
        resp.raise_for_status()
    except requests.exceptions.HTTPError as err:
        print("Could not create the files: {}".format(err))

    print(
        "{}: The repository files for repository of type {} "
        "were created successfully".format(resp.status_code, repository_item["type"])
    )

    return resp


def create_pipeline(name, repository_type, pipeline_folder_name):
    """
    Creates a pipeline if it doesn't already exist.
    :param name: The name of the pipeline that will be created
    :param repository_type:  The type of the repository
    :param pipeline_folder_name:  The name of the folder to put the pipeline in
    :return: the json response
    """
    print("Creating pipeline with name: {}".format(name))

    resp = ""

    try:
        resp = pipeline.create(name, repository_type, pipeline_folder_name)

        resp.raise_for_status()
        print(
            "{}: Successfully created pipeline "
            "with Id: {}".format(resp.status_code, resp.json()["id"])
        )

    except requests.exceptions.HTTPError as err:
        print("Could not create the pipeline: {}".format(err))

    return resp


process_file()

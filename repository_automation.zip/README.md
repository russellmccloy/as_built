# Introduction

The minimum version of Python supported in this project is 3.7

## Setting Up Python 3.x

> You should not need to do this generally unless you are changing / adding to the functionality of the code in this repository

Follow this:
<https://phoenixnap.com/kb/how-to-install-python-3-ubuntu>

If `python --version` shows an old version of python then do the following:

Place this into ~/.bashrc file: 

```bash
gedit ~/.bashrc
```

Go into the bashrc file and then at the top of the bashrc file make the following change.

```bash
alias python=python3
```

After adding the above in the file. run the below command:
(*I ran the first one*)

```bash
source ~/.bashrc
```

or

```bash
source ~/.bash_aliases
```

## Quick Start

* When opting to create a YAML pipeline you must **manually** create the pipeline / build folder here: <https://dev.azure.com/australiansuper/Cloud%20Capability/_build?view=folders>.
* You should look to see if there is an existing folder there before creating a new one. So, for example, if you are working on DSC then look for an existing DSC or similar folder.
* The Terraform state is stored in a storage container in Azure. This storage container is mentioned in your YAML pipeline if you have opted for one. You must manually create the Azure storage container before running your pipleline. Here is the storage container: <https://portal.azure.com/#@2e2e956a-b164-4b2b-904b-0be8fefb4b4b/resource/subscriptions/8ab21e60-6a27-4526-99f0-79e8395957f3/resourceGroups/Platforms-Shared-RG-002/providers/Microsoft.Storage/storageAccounts/shdstdgrsterrainf01/overview>

This repository is used to automate the creation of Azure DevOps repositories and optional YAML pipelines.
The user adds a new repository and type to the file (Please scroll down to view the available [RepositoryTypes](#Repository-Types)):  

```
\json_files\list_of_repositories.json
```

The user must add a whole new block as follows:

```json
{
    "name": "repo_name_that_fits_with_naming_standards",
    "create_pipeline": true,
    "pipeline_folder_name": "lets_be_more_organised",
    "type": "TERRAFORM_AZURERM"
}
```

or if you don't want to create a pipeline then the following will still work:

```json
{
    "name": "repo_name_that_fits_with_naming_standards_without_creating a pipeline", 
    "type": "TERRAFORM_AZURERM"
}
```

So let's look at a couple of scenarios:

_I'd like to create a repository so I can make a new Terraform module:_

```json
{
    "name": "terraform-azurerm-keyvault",
    "type": "TERRAFORM_AZURERM_MODULE"
}
```

>**_NOTE:_** if it is not a module then it should not begin with the prefix `terraform-azurerm-`

Another scenario could be:

_I'd like to write some Terraform code for a project i'm working on that consumes the above module code:_

```json
{
    "name": "member-portal-web-api", 
    "create_pipeline": true,
    "pipeline_folder_name": "member_portal",
    "type": "TERRAFORM_AZURERM"
}
```

(... And so on and so forth)

>**_Note:_** that if there is no pipeline.yaml code in the template for that repository type then no pipeline will be created:

This is what the pipeline part of a template looks like:

```json
{
  "changeType": "add",
  "item": {
    "path": "pipeline.yaml"
  },
  "newContent": {
    "content": "name: __build_def_prefix__$(BuildDefinitionName).$(Build.Reason)$(Rev:.r)\n",
    "contentType": "rawtext"
  }
},
```

>**_Note:_** that, at this point in time you will need to go into the terraform state shared storage account called: '**shdstdgrsterrainf01**' and create the container MANUALLY that is mentioned in the following code in your pipeline:

```yaml
variables:  
  - name: GIT_CURL_VERBOSE
value: 1
  - name: AgentFolder
    value: reddog
  - name: ConfSourceFolder
    value: 'TF' 
  - name: container
    value: 'your-container-for-terraform-state-tfstate'      <======= HERE
  - name: statefile
    value: 'your-file-for-terraform-state.tfstate' 
  - group: 'Tenancy Access Variables'  
```

## Repository Types

There are a few types of repository based on the following code:

|        Repository Type        |                                                                         Description                         |                       Variables                      |
|-------------------------------|-------------------------------------------------------------------------------------------------------------|------------------------------------------------|
| STANDARD                 | Nearly an empty repository if it the following types don't suit your needs                                                                                        |-**name** (req)<br/>-**create_pipeline** (opt)<br/>-**pipeline_folder_name** (opt)                                                                                                              |      
| TERRAFORM_AZURERM        | Use for an azurerm project that consumes Terraform module but is not a module itself. The pipeline, if added, will be a standard pipeline without a TFVARS File.  |-**name** (req)<br/>-**create_pipeline** (opt)<br/>-**pipeline_folder_name** (opt)|
| TERRAFORM_AZURERM_TFVARS | Use for an azurerm project that consumes Terraform module but is not a module itself. The pipeline, if added,  can work with a TFVARS file                        |-**name** (req)<br/>-**create_pipeline** (opt)<br/>-**pipeline_folder_name** (opt)<br/>-**solution** (req)<br/>-**env** (req)|
| TERRAFORM_GCP            | Use for an GCP project that consumes Terraform module                                                                                                             |-**name** (req)<br/>-**create_pipeline** (opt)<br/>-**pipeline_folder_name** (opt)|
| PY                       | Use for a Python project                                                                                                                                          |-**name** (req)|
| ANSIBLE                  | Use for an Ansible project                                                                                                                                        |-**name** (req)|
| TERRAFORM_AZURERM_MODULE | Use when you are creating a new azurerm Terraform module - name should start with 'terraform-azurerm-'                                                            |-**name** (req)|
| TERRAFORM_GCP_MODULE     | Use when you are creating a new GCP Terraform module - name should start with 'terraform -azurerm-'                                                               |-**name** (req)|

The type forces the code to create technology specific files in the repository.

This code should be called from Azure DevOps but can be called from the command line on your local machine for testing. Here is the format to make it work:

Note: when you generate a PAT in Azure DevOps you need to generate it then:

If, for example, you PAT is:

```python
123456
```

you need to put a colon in front of it before adding it 
as a variable in the pipeline. 
So if your PAT ends up looking like this:

```python
:123456
```

Pseudo:

```python
python main.py <DevOps PAT> <DevOps Project id> <DevOps Org> <DevOps Project name> <DevOps REST API version>
```

Real example but not showing you the secret:

```python
python main.py <SECRET> 553e696e-c449-46e4-a760-95b0eb618ed6 australiansuper Cloud%20Capability 5.1
```

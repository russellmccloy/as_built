import requests
import json
import globals


def _url(path):
    """
    Builds up the URL path based on the passed in variables
    :param path:  The specific path segment for the REST call
    :return: the full url including the passed in path
    """
    url = (
        "https://dev.azure.com/"
        + globals.Shared.ORG
        + "/"
        + globals.Shared.PROJECT
        + "/_apis/build"
        + path
        + "?api-version="
        + globals.Shared.VERSION
    )
    return url


def create(name, repository_type, path):
    """
    This function responds to a POST request to /build/definitions that creates a build / pipeline
    if it doesn't already exist.
    :param name:  The name of the build / pipeline that will be created
    :param repository_type:  The type of the repository
    :param path:  The name of the folder that the pipeline will live in
    :return: the result of the request
    """
    with open("json_files/pipeline.json") as pipeline_json:
        pipeline_json_data = json.load(pipeline_json)

    # " + repository_type.lower() + "_

    # manipulate the global setting variables before applying
    pipeline_json_data["project"]["id"] = globals.Shared.PROJECT_ID
    pipeline_json_data["project"]["name"] = globals.Shared.PROJECT
    pipeline_json_data["project"]["name"] = globals.Shared.PROJECT
    pipeline_json_data["project"][
        "url"
    ] = "https://dev.azure.com/{}/_apis/projects/{}".format(
        globals.Shared.ORG, globals.Shared.PROJECT_ID
    )
    pipeline_json_data["process"]["yamlFilename"] = "pipeline.yaml"

    # queue
    pipeline_json_data["queue"]["id"] = globals.Shared.QUEUE_ID
    pipeline_json_data["queue"]["name"] = globals.Shared.QUEUE_NAME
    pipeline_json_data["queue"]["url"] = globals.Shared.QUEUE_URL

    # pool
    pipeline_json_data["queue"]["pool"]["id"] = globals.Shared.QUEUE_POOL_ID
    pipeline_json_data["queue"]["pool"]["name"] = globals.Shared.QUEUE_POOL_NAME
    pipeline_json_data["queue"]["pool"][
        "isHosted"
    ] = globals.Shared.QUEUE_POOL_IS_HOSTED

    # Manipulate the passed in variables json before applying
    pipeline_json_data["name"] = name
    pipeline_json_data["repository"]["name"] = name
    pipeline_json_data["path"] = "\\" + path

    return requests.post(
        _url("/definitions"),
        json=pipeline_json_data,
        headers={"Authorization": "Basic " + globals.Shared.AUTH_TOKEN_ENCODED},
    )

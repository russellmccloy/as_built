import re

"""
This code validates repository naming etc
"""


def validate(repository_item):
    """
    This function validates the name of the repository.
    :param repository_item:  The details of the repository
    :return: a bool stating whether the input is valid or not
    """

    if repository_item["type"] == "TERRAFORM_AZURERM_MODULE":
        if not re.match(r"terraform-azurerm-", repository_item["name"]):
            print(
                "A repository of type TERRAFORM_AZURERM_MODULE must start with a lowercase "
                "'terraform-azurerm-' "
            )
            return False
        else:
            print(
                "The repository name {} for type {} is valid".format(
                    repository_item["name"], repository_item["type"]
                )
            )
            return True

    if repository_item["type"] == "TERRAFORM_GCP_MODULE":
        if not re.match(r"terraform-gcp-", repository_item["name"]):
            print(
                "A repository of type TERRAFORM_GCP_MODULE must start "
                "with a lowercase 'terraform-gcp-'"
            )
            return False
        else:
            return True

    return True
